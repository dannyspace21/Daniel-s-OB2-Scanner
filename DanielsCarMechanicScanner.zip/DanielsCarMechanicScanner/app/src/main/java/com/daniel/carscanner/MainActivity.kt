package com.daniel.carscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import android.content.res.Configuration
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daniel.carscanner.ui.LocalTorch
import com.daniel.carscanner.ui.ThemeMode
import com.daniel.carscanner.ui.Torch
import com.daniel.carscanner.ui.Ui
import com.daniel.carscanner.ui.AppRoot
import com.daniel.carscanner.ui.CarScannerTheme
import com.daniel.carscanner.ui.ScannerViewModel

/*
 * WHAT THIS FILE DOES
 * The app's entry point. Android starts here when you tap the icon. It:
 *  1. keeps the screen on (handy in the garage)
 *  2. asks for Bluetooth permission if needed
 *  3. sets up day/night mode and the flashlight
 *  4. shows the app's screens (AppRoot)
 *  5. turns the flashlight off when you leave the app
 */
class MainActivity : ComponentActivity() {

    private val vm: ScannerViewModel by viewModels()
    private val hasPermission = mutableStateOf(false)
    private lateinit var torch: Torch

    private val perms: Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private val launcher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        hasPermission.value = res.values.all { it }
        if (hasPermission.value) vm.refreshDevices()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hasPermission.value = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (hasPermission.value) vm.refreshDevices() else launcher.launch(perms)
        torch = Torch(this)

        // Pick the right colors before the first frame, so there's no flash of the wrong theme.
        val systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        Ui.use(when (vm.themeMode.value) { ThemeMode.System -> systemDark; ThemeMode.Light -> false; ThemeMode.Dark -> true })

        setContent {
            val mode by vm.themeMode.collectAsStateWithLifecycle()
            CarScannerTheme(mode) {
                CompositionLocalProvider(LocalTorch provides torch) {
                    AppRoot(vm, hasPermission.value) { launcher.launch(perms) }
                }
            }
        }
    }

    /** Leaving the app (home button, switching apps): turn the flashlight off. */
    override fun onStop() {
        super.onStop()
        if (torch.isOn) torch.set(false)
    }

    override fun onDestroy() {
        torch.release()
        super.onDestroy()
    }
}
