package com.daniel.carscanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daniel.carscanner.net.BodyShape
import com.daniel.carscanner.net.CabSize

/*
 * WHAT THIS FILE DOES
 * Everything about the car itself:
 *  - the big drawing, with buttons to preview the lights and doors
 *  - paint color picker (the VIN doesn't record color, so you choose once)
 *  - details decoded from the VIN by NHTSA
 *  - a box to type a VIN, for cars that don't report it
 *  - open safety recalls, each linking to its nhtsa.gov page
 */
@Composable
fun VehicleScreen(vm: ScannerViewModel, onBack: () -> Unit) {
    val info by vm.vehicle.collectAsStateWithLifecycle()
    val vin by vm.vin.collectAsStateWithLifecycle()
    val recalls by vm.recalls.collectAsStateWithLifecycle()
    val status by vm.vehicleStatus.collectAsStateWithLifecycle()
    val paint by vm.paint.collectAsStateWithLifecycle()
    val head by vm.headlightsOn.collectAsStateWithLifecycle()
    val tail by vm.taillightsOn.collectAsStateWithLifecycle()
    val doors by vm.openDoors.collectAsStateWithLifecycle()
    var vinInput by remember { mutableStateOf("") }
    val uri = LocalUriHandler.current

    Page("Vehicle", onBack) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
            // The car, with preview buttons
            item {
                VehicleView(
                    shape = info?.shape ?: BodyShape.Sedan, doors = info?.doorCount ?: 4, cab = info?.cab ?: CabSize.Regular,
                    paint = Color(paint), headlights = head, taillights = tail, openDoors = doors,
                    modifier = Modifier.fillMaxWidth().height(300.dp), dim = info == null,
                )
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton(if (head) "Lights off" else "Headlights", modifier = Modifier.weight(1f)) { vm.previewHeadlights() }
                    SecondaryButton(if (tail) "Brakes off" else "Brake lights", modifier = Modifier.weight(1f)) { vm.previewTaillights() }
                    SecondaryButton("Doors", modifier = Modifier.weight(1f)) { vm.previewDoors() }
                }
                Text("Previews only animate the drawing. They don't send anything to the car.", color = Ui.Sub,
                    style = MaterialTheme.typography.bodySmall)
            }

            // Paint color
            item {
                Text("Paint color", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp, bottom = 10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(PaintColors) { (name, value) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(Color(value))
                                    .border(if (value == paint) 3.dp else 1.dp, if (value == paint) Ui.Accent else Ui.Line, CircleShape)
                                    .clickable { vm.setPaint(value) },
                            )
                            Text(name, style = MaterialTheme.typography.bodySmall, color = Ui.Sub, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            // Details from the VIN
            item {
                Text("Details", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp, bottom = 6.dp))
                if (status != null) Text(status ?: "", color = Ui.Sub)
                val i = info
                if (i != null) {
                    listOf(
                        "Year" to i.year, "Make" to i.makeName, "Model" to i.model, "Trim" to listOf(i.series, i.trim).filter { it.isNotBlank() }.joinToString(" "),
                        "Body" to i.bodyClass, "Doors" to (i.doors?.toString() ?: ""), "Cab" to i.cabType, "Engine" to i.engine,
                        "Drive" to i.driveType, "Fuel" to i.fuel,
                    ).filter { it.second.isNotBlank() }.forEach { (k, v) -> Detail(k, v) }
                }
                Detail("VIN", vin ?: "Not known yet")
            }

            // Type a VIN
            item {
                Text("Enter a VIN", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp, bottom = 6.dp))
                Text("For cars that don't report their VIN, or to look up a different car. It's on the dash at the bottom of the windshield and on the driver's door jamb.",
                    color = Ui.Sub, style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                    OutlinedTextField(
                        vinInput, { vinInput = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(17) },
                        singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                        placeholder = { Text("17 characters") },
                        supportingText = { Text("${vinInput.length}/17") },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    )
                    Spacer(Modifier.width(10.dp))
                    PrimaryButton("Look up", enabled = vinInput.length == 17) { vm.setVinManually(vinInput); vinInput = "" }
                }
            }

            // Recalls
            item {
                Text(
                    when {
                        info == null -> "Recalls"
                        recalls.isEmpty() -> "Recalls: none found"
                        else -> "Recalls: ${recalls.size}"
                    },
                    style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp, bottom = 6.dp),
                )
                if (info != null && recalls.isNotEmpty()) Text(
                    "These are all recalls for this year, make and model. Your dealer can tell you which apply to your VIN and whether they've been done.",
                    color = Ui.Sub, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp),
                )
            }
            items(recalls, key = { it.campaign }) { r ->
                var open by remember { mutableStateOf(false) }
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(Ui.Card)
                        .clickable { open = !open }.padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusDot(if (r.parkIt) Ui.Bad else Ui.Watch)
                        Spacer(Modifier.width(8.dp))
                        Text(r.component, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                    }
                    if (r.parkIt) Text("NHTSA says: don't drive until fixed", color = Ui.Bad, style = MaterialTheme.typography.labelMedium)
                    Text(r.summary, maxLines = if (open) Int.MAX_VALUE else 3, modifier = Modifier.padding(top = 6.dp))
                    if (open) {
                        if (r.consequence.isNotBlank()) { Label("Risk"); Text(r.consequence) }
                        if (r.remedy.isNotBlank()) { Label("Fix"); Text(r.remedy) }
                        TextButton(onClick = { uri.openUri(r.url) }) { Text("Open on nhtsa.gov", color = Ui.Accent) }
                    }
                    Text("Campaign ${r.campaign}${if (r.date.isNotBlank()) ", ${r.date}" else ""}", color = Ui.Sub,
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

/** Small grey heading inside a card. */
@Composable
private fun Label(text: String) {
    Text(text, color = Ui.Sub, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
}

/** A label/value line. */
@Composable
private fun Detail(label: String, value: String) {
    Row(Modifier.padding(vertical = 5.dp)) {
        Text(label, color = Ui.Sub, modifier = Modifier.width(84.dp))
        Text(value)
    }
}
