package com.daniel.carscanner.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.luminance
import com.daniel.carscanner.net.BodyShape
import com.daniel.carscanner.net.CabSize

/*
 * WHAT THIS FILE DOES
 * Draws the car on the Home screen, seen from above like the Tesla app.
 * Everything is drawn with code (no image files), so one drawing adapts to:
 *   - body style from the VIN: coupe, sedan, hatchback, wagon, SUV, van,
 *     pickup (regular, extended or crew cab) or motorcycle
 *   - number of doors from the VIN
 *   - the paint color you pick (the VIN doesn't record color)
 * and animates:
 *   - headlights glowing with light beams
 *   - tail/brake lights glowing red
 *   - doors swinging open on their hinges
 *
 * Coordinates: the car points UP. Positions along the car are fractions of its
 * length (0 = front bumper, 1 = rear bumper), across the car are fractions of
 * its width (0 = left side, 1 = right side).
 */

/** Paint colors you can choose from on the Vehicle screen. */
val PaintColors = listOf(
    "White" to 0xFFEDEEF0, "Silver" to 0xFFB9BDC3, "Gray" to 0xFF6E737A, "Black" to 0xFF1E1F22,
    "Red" to 0xFFB3261E, "Blue" to 0xFF2F5BD3, "Navy" to 0xFF1F2F55, "Green" to 0xFF2E6B4F,
    "Orange" to 0xFFE46A1C, "Yellow" to 0xFFE6B800, "Bronze" to 0xFF7A5A3C,
)

/** Door numbers used by the animations. */
object Door { const val FL = 0; const val FR = 1; const val RL = 2; const val RR = 3 }

/**
 * Where things sit along each body style, as fractions of the length.
 * ratio     length divided by width
 * ws0..ws1  windshield
 * roofEnd   end of the roof
 * rear1     end of the rear window
 * axles     front and rear wheel centers
 * bedStart  pickups only: where the bed starts
 */
private class Spec(
    val ratio: Float, val ws0: Float, val ws1: Float, val roofEnd: Float, val rear1: Float,
    val frontAxle: Float, val rearAxle: Float, val bedStart: Float? = null,
)

private fun specFor(shape: BodyShape, cab: CabSize): Spec = when (shape) {
    BodyShape.Coupe -> Spec(2.25f, 0.36f, 0.47f, 0.64f, 0.77f, 0.17f, 0.80f)
    BodyShape.Sedan -> Spec(2.45f, 0.32f, 0.42f, 0.63f, 0.74f, 0.16f, 0.80f)
    BodyShape.Hatchback -> Spec(2.15f, 0.30f, 0.40f, 0.80f, 0.90f, 0.16f, 0.82f)
    BodyShape.Wagon -> Spec(2.50f, 0.30f, 0.40f, 0.84f, 0.92f, 0.16f, 0.81f)
    BodyShape.SUV -> Spec(2.30f, 0.28f, 0.38f, 0.84f, 0.93f, 0.17f, 0.81f)
    BodyShape.Van -> Spec(2.55f, 0.14f, 0.25f, 0.90f, 0.95f, 0.13f, 0.80f)
    BodyShape.Pickup -> {
        val roofEnd = when (cab) { CabSize.Regular -> 0.43f; CabSize.Extended -> 0.49f; CabSize.Crew -> 0.55f }
        Spec(2.85f, 0.25f, 0.33f, roofEnd, roofEnd + 0.035f, 0.15f, 0.80f, bedStart = roofEnd + 0.06f)
    }
    BodyShape.Motorcycle -> Spec(3.2f, 0f, 0f, 0f, 0f, 0f, 0f)
}

/** Darker (f < 1) or lighter (f > 1) version of a color. */
private fun Color.shade(f: Float) = Color(
    (red * f).coerceIn(0f, 1f), (green * f).coerceIn(0f, 1f), (blue * f).coerceIn(0f, 1f), alpha,
)

private val Glass = Color(0xFF1C2129)
private val Tire = Color(0xFF0B0B0C)
private val BeamColor = Color(0xFFFFF4D6)

/**
 * The car drawing.
 * dim = true draws a faded placeholder (when no car is known yet).
 */
@Composable
fun VehicleView(
    shape: BodyShape,
    doors: Int,
    cab: CabSize,
    paint: Color,
    headlights: Boolean,
    taillights: Boolean,
    openDoors: Set<Int>,
    modifier: Modifier = Modifier,
    dim: Boolean = false,
) {
    // Smoothly animated values (0 = off/closed, 1 = on/open)
    val head by animateFloatAsState(if (headlights) 1f else 0f, tween(450), label = "head")
    val tail by animateFloatAsState(if (taillights) 1f else 0f, tween(300), label = "tail")
    val doorSpring = spring<Float>(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow)
    val d0 by animateFloatAsState(if (Door.FL in openDoors) 1f else 0f, doorSpring, label = "d0")
    val d1 by animateFloatAsState(if (Door.FR in openDoors) 1f else 0f, doorSpring, label = "d1")
    val d2 by animateFloatAsState(if (Door.RL in openDoors) 1f else 0f, doorSpring, label = "d2")
    val d3 by animateFloatAsState(if (Door.RR in openDoors) 1f else 0f, doorSpring, label = "d3")

    Canvas(modifier) {
        val spec = specFor(shape, cab)
        // Leave room above the car for headlight beams, and at the sides for open doors.
        val top = size.height * 0.2f
        val area = size.height * 0.97f - top
        val length = minOf(area, size.width * spec.ratio / 2.1f)
        val width = length / spec.ratio
        val x0 = (size.width - width) / 2f
        val y0 = top + (area - length) / 2f
        val alpha = if (dim) 0.35f else 1f
        val car = Geometry(x0, y0, width, length)

        if (shape == BodyShape.Motorcycle) {
            drawMotorcycle(car, paint.copy(alpha = alpha), head, tail)
        } else {
            drawCar(car, spec, shape, doors, paint.copy(alpha = alpha), head, tail, floatArrayOf(d0, d1, d2, d3), alpha)
        }
    }
}

/** Converts car fractions into screen pixels. */
private class Geometry(val x0: Float, val y0: Float, val w: Float, val l: Float) {
    fun x(f: Float) = x0 + f * w
    fun y(f: Float) = y0 + f * l
}

/** Draws a 4-wheeled vehicle. */
private fun DrawScope.drawCar(
    g: Geometry, spec: Spec, shape: BodyShape, doorCount: Int, paint: Color,
    head: Float, tail: Float, doorOpen: FloatArray, alpha: Float,
) {
    val outline = if (paint.luminance() < 0.15f) Color(0xFF55595F) else paint.shade(0.7f)

    // 1. Headlight beams (behind everything)
    if (head > 0.01f) {
        for (lx in listOf(g.x(0.22f), g.x(0.78f))) {
            val ly = g.y(0.03f)
            val endY = g.y0 - size.height * 0.18f
            val beam = Path().apply {
                moveTo(lx - g.w * 0.05f, ly)
                lineTo(lx - g.w * 0.32f, endY)
                lineTo(lx + g.w * 0.32f, endY)
                lineTo(lx + g.w * 0.05f, ly)
                close()
            }
            drawPath(beam, Brush.verticalGradient(
                listOf(BeamColor.copy(alpha = 0f), BeamColor.copy(alpha = 0.32f * head)), startY = endY, endY = ly,
            ))
        }
    }

    // 2. Wheels peeking out from under the body
    val tw = g.w * 0.13f; val tl = g.l * 0.15f
    for (axle in listOf(spec.frontAxle, spec.rearAxle)) {
        val cy = g.y(axle) - tl / 2
        drawRoundRect(Tire.copy(alpha = alpha), Offset(g.x0 - tw * 0.35f, cy), Size(tw, tl), CornerRadius(tw * 0.3f))
        drawRoundRect(Tire.copy(alpha = alpha), Offset(g.x0 + g.w - tw * 0.65f, cy), Size(tw, tl), CornerRadius(tw * 0.3f))
    }

    // 3. Openings where doors have swung away (dark interior)
    val spans = doorSpans(spec, shape, doorCount)
    spans.forEach { (index, span) ->
        val open = doorOpen[index]
        if (open > 0.01f) {
            val left = index == Door.FL || index == Door.RL
            val x = if (left) g.x0 else g.x0 + g.w * 0.93f
            drawRect(Color(0xFF2A2A2E).copy(alpha = alpha * open), Offset(x, g.y(span.first)), Size(g.w * 0.07f, g.y(span.second) - g.y(span.first)))
        }
    }

    // 4. Body shell, rounder at the front
    val body = Path().apply {
        addRoundRect(RoundRect(
            left = g.x0, top = g.y0, right = g.x0 + g.w, bottom = g.y0 + g.l,
            topLeftCornerRadius = CornerRadius(g.w * 0.30f, g.w * 0.34f), topRightCornerRadius = CornerRadius(g.w * 0.30f, g.w * 0.34f),
            bottomLeftCornerRadius = CornerRadius(g.w * 0.20f, g.w * 0.18f), bottomRightCornerRadius = CornerRadius(g.w * 0.20f, g.w * 0.18f),
        ))
    }
    drawPath(body, paint)
    // Soft shading at the edges gives a rounded, 3D feel
    drawPath(body, Brush.horizontalGradient(
        listOf(Color.Black.copy(alpha = 0.22f * alpha), Color.Transparent, Color.White.copy(alpha = 0.06f * alpha), Color.Transparent, Color.Black.copy(alpha = 0.22f * alpha)),
        startX = g.x0, endX = g.x0 + g.w,
    ))
    drawPath(body, outline.copy(alpha = alpha), style = Stroke(width = g.w * 0.012f))

    // 5. Pickup bed
    spec.bedStart?.let { bs ->
        drawRoundRect(paint.shade(0.55f), Offset(g.x(0.1f), g.y(bs)), Size(g.w * 0.8f, g.y(0.955f) - g.y(bs)), CornerRadius(g.w * 0.03f))
        drawLine(outline.copy(alpha = alpha), Offset(g.x(0.1f), g.y(0.955f)), Offset(g.x(0.9f), g.y(0.955f)), strokeWidth = g.w * 0.012f)
    }

    // 6. Glass: windshield, side windows, roof and rear window
    val glass = Glass.copy(alpha = alpha)
    trapezoid(g, spec.ws0, spec.ws1, 0.17f, 0.11f, glass)
    drawRect(paint.shade(0.86f), Offset(g.x(0.11f), g.y(spec.ws1)), Size(g.w * 0.78f, g.y(spec.roofEnd) - g.y(spec.ws1)))
    drawRect(glass, Offset(g.x(0.07f), g.y(spec.ws1)), Size(g.w * 0.04f, g.y(spec.roofEnd) - g.y(spec.ws1)))
    drawRect(glass, Offset(g.x(0.89f), g.y(spec.ws1)), Size(g.w * 0.04f, g.y(spec.roofEnd) - g.y(spec.ws1)))
    trapezoid(g, spec.roofEnd, spec.rear1, 0.11f, 0.18f, glass)

    // 7. Side mirrors
    val my = g.y(spec.ws0 + 0.01f)
    drawOval(paint.shade(0.8f), Offset(g.x0 - g.w * 0.07f, my), Size(g.w * 0.11f, g.l * 0.035f))
    drawOval(paint.shade(0.8f), Offset(g.x0 + g.w * 0.96f, my), Size(g.w * 0.11f, g.l * 0.035f))

    // 8. Headlights and taillights, with glow when on
    val headColor = lerpColor(Color(0xFFC9CED6), Color.White, head).copy(alpha = alpha)
    val tailColor = lerpColor(Color(0xFF6B1A1A), Color(0xFFFF3B30), tail).copy(alpha = alpha)
    for ((lx, ly) in listOf(g.x(0.1f) to g.y(0.018f), g.x(0.68f) to g.y(0.018f))) {
        drawRoundRect(headColor, Offset(lx, ly), Size(g.w * 0.22f, g.l * 0.026f), CornerRadius(g.w * 0.03f))
        if (head > 0.01f) glow(Offset(lx + g.w * 0.11f, ly + g.l * 0.013f), g.w * 0.28f, BeamColor, 0.55f * head)
    }
    for ((lx, ly) in listOf(g.x(0.08f) to g.y(0.968f), g.x(0.70f) to g.y(0.968f))) {
        drawRoundRect(tailColor, Offset(lx, ly), Size(g.w * 0.22f, g.l * 0.018f), CornerRadius(g.w * 0.02f))
        if (tail > 0.01f) glow(Offset(lx + g.w * 0.11f, ly + g.l * 0.009f), g.w * 0.3f, Color(0xFFFF3B30), 0.5f * tail)
    }

    // 9. Doors: seams when closed, panels swung out on their front hinge when open
    spans.forEach { (index, span) ->
        val left = index == Door.FL || index == Door.RL
        val ys = g.y(span.first); val ye = g.y(span.second)
        val seam = outline.copy(alpha = alpha * 0.9f)
        val edgeX = if (left) g.x0 else g.x0 + g.w
        val inX = if (left) g.x0 + g.w * 0.07f else g.x0 + g.w * 0.93f
        drawLine(seam, Offset(edgeX, ys), Offset(inX, ys), strokeWidth = g.w * 0.01f)
        drawLine(seam, Offset(edgeX, ye), Offset(inX, ye), strokeWidth = g.w * 0.01f)
        val open = doorOpen[index]
        if (open > 0.01f) {
            val thick = g.w * 0.06f
            val angle = 62f * open * (if (left) 1f else -1f)
            rotate(angle, pivot = Offset(edgeX, ys)) {
                val dx = if (left) edgeX - thick else edgeX
                drawRoundRect(paint, Offset(dx, ys), Size(thick, ye - ys), CornerRadius(thick * 0.4f))
                drawRoundRect(outline.copy(alpha = alpha), Offset(dx, ys), Size(thick, ye - ys), CornerRadius(thick * 0.4f), style = Stroke(g.w * 0.01f))
            }
        }
    }
}

/**
 * Which doors exist and where they are along the car: door number -> (start, end).
 * 2-door cars get long front doors; 4-door cars split the cabin in two.
 */
private fun doorSpans(spec: Spec, shape: BodyShape, doorCount: Int): List<Pair<Int, Pair<Float, Float>>> {
    if (doorCount <= 0) return emptyList()
    val start = spec.ws0 + 0.02f
    val end = (if (shape == BodyShape.Van) spec.ws1 + 0.35f else spec.roofEnd) - 0.015f
    return if (doorCount < 4) {
        listOf(Door.FL to (start to end), Door.FR to (start to end))
    } else {
        val mid = (start + end) / 2f + 0.01f
        listOf(Door.FL to (start to mid), Door.FR to (start to mid), Door.RL to (mid to end), Door.RR to (mid to end))
    }
}

/** Draws a 4-sided window shape between two points along the car. inset = how far in from the sides. */
private fun DrawScope.trapezoid(g: Geometry, f0: Float, f1: Float, inset0: Float, inset1: Float, color: Color) {
    if (f1 <= f0) return
    val p = Path().apply {
        moveTo(g.x(inset0), g.y(f0)); lineTo(g.x(1f - inset0), g.y(f0))
        lineTo(g.x(1f - inset1), g.y(f1)); lineTo(g.x(inset1), g.y(f1)); close()
    }
    drawPath(p, color)
}

/** A soft round glow around a light. */
private fun DrawScope.glow(center: Offset, radius: Float, color: Color, strength: Float) {
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = strength), Color.Transparent), center, radius), radius, center)
}

/** Blends two colors: t = 0 gives a, t = 1 gives b. */
private fun lerpColor(a: Color, b: Color, t: Float) = Color(
    a.red + (b.red - a.red) * t, a.green + (b.green - a.green) * t, a.blue + (b.blue - a.blue) * t, 1f,
)

/** Draws a motorcycle from above: wheels, bars, tank, seat and lights. */
private fun DrawScope.drawMotorcycle(g: Geometry, paint: Color, head: Float, tail: Float) {
    val cx = g.x0 + g.w / 2
    if (head > 0.01f) {
        val ly = g.y(0.17f); val endY = g.y0 - size.height * 0.18f
        val beam = Path().apply {
            moveTo(cx - g.w * 0.08f, ly); lineTo(cx - g.w * 0.7f, endY); lineTo(cx + g.w * 0.7f, endY); lineTo(cx + g.w * 0.08f, ly); close()
        }
        drawPath(beam, Brush.verticalGradient(listOf(BeamColor.copy(alpha = 0f), BeamColor.copy(alpha = 0.32f * head)), startY = endY, endY = ly))
    }
    drawRoundRect(Tire, Offset(cx - g.w * 0.12f, g.y(0.0f)), Size(g.w * 0.24f, g.l * 0.2f), CornerRadius(g.w * 0.1f))
    drawRoundRect(Tire, Offset(cx - g.w * 0.16f, g.y(0.74f)), Size(g.w * 0.32f, g.l * 0.26f), CornerRadius(g.w * 0.12f))
    drawLine(Color(0xFF3A3D42), Offset(g.x0, g.y(0.24f)), Offset(g.x0 + g.w, g.y(0.24f)), strokeWidth = g.w * 0.07f)
    drawCircle(Color(0xFF3A3D42), g.w * 0.07f, Offset(g.x0, g.y(0.24f)))
    drawCircle(Color(0xFF3A3D42), g.w * 0.07f, Offset(g.x0 + g.w, g.y(0.24f)))
    drawOval(paint, Offset(cx - g.w * 0.42f, g.y(0.28f)), Size(g.w * 0.84f, g.l * 0.24f))
    drawOval(Color.White.copy(alpha = 0.08f), Offset(cx - g.w * 0.2f, g.y(0.31f)), Size(g.w * 0.3f, g.l * 0.14f))
    drawRoundRect(Color(0xFF222326), Offset(cx - g.w * 0.28f, g.y(0.5f)), Size(g.w * 0.56f, g.l * 0.22f), CornerRadius(g.w * 0.2f))
    drawCircle(lerpColor(Color(0xFFC9CED6), Color.White, head), g.w * 0.12f, Offset(cx, g.y(0.17f)))
    if (head > 0.01f) glow(Offset(cx, g.y(0.17f)), g.w * 0.6f, BeamColor, 0.55f * head)
    drawRoundRect(lerpColor(Color(0xFF6B1A1A), Color(0xFFFF3B30), tail), Offset(cx - g.w * 0.15f, g.y(0.73f)), Size(g.w * 0.3f, g.l * 0.02f), CornerRadius(g.w * 0.05f))
    if (tail > 0.01f) glow(Offset(cx, g.y(0.74f)), g.w * 0.6f, Color(0xFFFF3B30), 0.5f * tail)
}
